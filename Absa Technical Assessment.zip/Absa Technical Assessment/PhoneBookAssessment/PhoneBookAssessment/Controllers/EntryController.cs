﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PhoneBookAssessment.Model;
using PhoneBookAssessment.Roposatory;
using PhoneBookAssessment.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PhoneBookAssessment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EntryController : ControllerBase
    {

        public readonly IEntryReposatory _entryReposatory;

        public EntryController(IEntryReposatory entryReposatory)
        {

            _entryReposatory = entryReposatory;
        }


        [HttpGet]
        public async Task<IEnumerable<Entry>> GetEntries()
        {
            return await _entryReposatory.GetEntries();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Entry>> GeEntryById(int id)

        {
            var record = await _entryReposatory.GetEntryById(id);
            if (record == null)
            {
                return BadRequest("Record not found");

            }

            return record;
        }

        [HttpPost]
        public async Task<ActionResult<Entry>> CreateEntry([FromBody] EntryViewModel entryViewModel)
        {

            if (ModelState.IsValid)
            {
                  Entry entry = new Entry();
                EntryViewModel eViewModel = new EntryViewModel();

                if (entryViewModel.TypeEntry.ToLower() == "cell")
                {
                    entry.entry_Id = entryViewModel.Entry_Id;
                    entry.name = entryViewModel.name;
                    entry.phoneNumber = entryViewModel.Phone_Number;
                    entry.phone_bookId = entryViewModel.phone_BookId;

                }
                if (entryViewModel.TypeEntry.ToLower() != "cell" && entryViewModel.TypeEntry.ToLower() != "home")
                {
                    return BadRequest("Type  must be  Cell or Home");
                }
                
                if (entryViewModel.TypeEntry.ToLower() == "home")
                {
                    entry.entry_Id = entryViewModel.Entry_Id;
                    entry.name = entryViewModel.name;
                    entry.phoneNumber = entryViewModel.Telephone_Number;
                    entry.phone_bookId = entryViewModel.phone_BookId;

                }

                if (entryViewModel.TypeEntry.ToLower() != "home" && entryViewModel.TypeEntry.ToLower() != "cell")
                {
                    return BadRequest("Type  must be  Cell or Home");
                }

                
                var newEntry = await _entryReposatory.CreateEntry(entry);
                return CreatedAtAction(nameof(GetEntries), new { id = newEntry.entry_Id }, newEntry);

            }

            return BadRequest("Record inserting is invalid");
        }

        [HttpDelete]
        public async Task<ActionResult> DeleteEntry(int id)
        {

            var entryToDelete = await _entryReposatory.GetEntryById(id);
            if (entryToDelete == null)
            {
                return BadRequest("Record to delete not found");

            }

            await _entryReposatory.DeleteEntry(entryToDelete.entry_Id);
            return NoContent();

        }



    }
}
