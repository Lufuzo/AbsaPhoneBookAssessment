﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PhoneBookAssessment.Model;
using PhoneBookAssessment.Roposatory;
using PhoneBookAssessment.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;



namespace PhoneBookAssessment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PhoneBookController : ControllerBase
    {

        public readonly IPhoneBookReposatory _phoneBookEntryReposatory;

        public PhoneBookController(IPhoneBookReposatory phoneBookEntryReposatory)
        {

            _phoneBookEntryReposatory = phoneBookEntryReposatory;
        }

        [HttpGet]
        public async Task<IEnumerable<PhoneBook>> GetPhoneBookEntries()
        {
            return await _phoneBookEntryReposatory.GetPhoneBookEntries();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<PhoneBook>> GetPhoneBookEntryById(int id)

        {
            var record = await _phoneBookEntryReposatory.GetPhoneBookEntryById(id);
            if (record == null)
            {
                return BadRequest("Record not found");

            }

            return record;
        }

     
        [HttpPost]
        public async Task<ActionResult<PhoneBook>> CreatePhoneBookEntry([FromBody] PhoneBookViewModel phoneBookViewModel)
        {

            if (ModelState.IsValid)
            {
                PhoneBook phoneBook = new PhoneBook();

                phoneBook.phone_bookId = phoneBookViewModel.phone_BookId;
                phoneBook.name = phoneBookViewModel.name;


                var newEntry = await _phoneBookEntryReposatory.CreatePhoneBookEntry(phoneBook);
                return CreatedAtAction(nameof(GetPhoneBookEntries), new { id = newEntry.phone_bookId }, newEntry);
                
            }

            return BadRequest("Record inserting is invalid");
        }



        [HttpDelete]
        public async Task<ActionResult> DeleteOhoneBookEntry(int id)
        {

            var entryToDelete = await _phoneBookEntryReposatory.GetPhoneBookEntryById(id);
            if (entryToDelete == null)
            {
                return BadRequest("Record to delete not found");

            }

            await _phoneBookEntryReposatory.DeletePhoneBookEntry(entryToDelete.phone_bookId);
            return NoContent();

        }





    }
}
