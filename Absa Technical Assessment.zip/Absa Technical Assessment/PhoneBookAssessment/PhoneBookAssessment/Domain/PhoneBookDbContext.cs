﻿using Microsoft.EntityFrameworkCore;
using PhoneBookAssessment.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PhoneBookAssessment.Domain
{
    public class PhoneBookDbContext : DbContext
    {

        private readonly string ConnectionString;

        public PhoneBookDbContext(string connectionString)
        {
            this.ConnectionString = connectionString;

        }
        public PhoneBookDbContext(DbContextOptions<PhoneBookDbContext> options)
               : base(options)
        {
            Database.EnsureCreated();
        }

        public DbSet<PhoneBook> PhoneBookEntries { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlite(ConnectionString);

            }
        }
    }
}
