﻿using Microsoft.EntityFrameworkCore;
using PhoneBookAssessment.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PhoneBookAssessment.Domain
{
    public class EntryDbContext : DbContext
    {

        private readonly string ConnectionString;

        public EntryDbContext(string connectionString)
        {
            this.ConnectionString = connectionString;

        }
        public EntryDbContext(DbContextOptions<EntryDbContext> options)
               : base(options)
        {
            Database.EnsureCreated();
        }

        public DbSet<Entry> Entries { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlite(ConnectionString);

            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<Entry>()
            .Property(b => b.entry_Id)
            .HasColumnName("phone_bookId");

           modelBuilder.Entity<Entry>()
              .HasOne<Entry>(d => d.Entrys)
              .WithMany(dm => dm.Entries)
             .HasForeignKey(dkey => dkey.phone_bookId);
            
                // .HasOne<Entry>(d => d.Entrys)
                // .WithOne()
                //.OnDelete(DeleteBehavior.Cascade);

        }

       

    }


}
