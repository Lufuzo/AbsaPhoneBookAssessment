﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace PhoneBookAssessment.Migrations.PhoneBookDb
{
    public partial class PhoneBookMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "PhoneBookEntries",
                columns: table => new
                {
                    phone_bookId = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    name = table.Column<string>(type: "TEXT", nullable: true),
                    Discriminator = table.Column<string>(type: "TEXT", nullable: false),
                    entry_Id = table.Column<int>(type: "INTEGER", nullable: true),
                    phoneNumber = table.Column<string>(type: "TEXT", nullable: true),
                    Entrysphone_bookId = table.Column<int>(type: "INTEGER", nullable: true),
                    PhoneBookphone_bookId = table.Column<int>(type: "INTEGER", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PhoneBookEntries", x => x.phone_bookId);
                    table.ForeignKey(
                        name: "FK_PhoneBookEntries_PhoneBookEntries_Entrysphone_bookId",
                        column: x => x.Entrysphone_bookId,
                        principalTable: "PhoneBookEntries",
                        principalColumn: "phone_bookId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PhoneBookEntries_PhoneBookEntries_PhoneBookphone_bookId",
                        column: x => x.PhoneBookphone_bookId,
                        principalTable: "PhoneBookEntries",
                        principalColumn: "phone_bookId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PhoneBookEntries_Entrysphone_bookId",
                table: "PhoneBookEntries",
                column: "Entrysphone_bookId");

            migrationBuilder.CreateIndex(
                name: "IX_PhoneBookEntries_PhoneBookphone_bookId",
                table: "PhoneBookEntries",
                column: "PhoneBookphone_bookId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PhoneBookEntries");
        }
    }
}
