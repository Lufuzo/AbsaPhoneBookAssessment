﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace PhoneBookAssessment.Migrations
{
    public partial class EntryMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Entries",
                columns: table => new
                {
                    phone_bookId1 = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    phone_bookId = table.Column<int>(type: "INTEGER", nullable: false),
                    phoneNumber = table.Column<string>(type: "TEXT", nullable: true),
                    Entrysphone_bookId = table.Column<int>(type: "INTEGER", nullable: true),
                    Entryphone_bookId = table.Column<int>(type: "INTEGER", nullable: true),
                    name = table.Column<string>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Entries", x => x.phone_bookId1);
                    table.ForeignKey(
                        name: "FK_Entries_Entries_Entryphone_bookId",
                        column: x => x.Entryphone_bookId,
                        principalTable: "Entries",
                        principalColumn: "phone_bookId1",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Entries_Entries_Entrysphone_bookId",
                        column: x => x.Entrysphone_bookId,
                        principalTable: "Entries",
                        principalColumn: "phone_bookId1",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Entries_Entryphone_bookId",
                table: "Entries",
                column: "Entryphone_bookId");

            migrationBuilder.CreateIndex(
                name: "IX_Entries_Entrysphone_bookId",
                table: "Entries",
                column: "Entrysphone_bookId",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Entries");
        }
    }
}
