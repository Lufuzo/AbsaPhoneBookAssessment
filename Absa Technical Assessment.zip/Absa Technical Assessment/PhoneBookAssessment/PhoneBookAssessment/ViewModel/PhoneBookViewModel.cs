﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PhoneBookAssessment.ViewModel
{
    public class PhoneBookViewModel
    {
        [Key]
        public int phone_BookId { get; set; }
        public string name { get; set; }
       
    }
}
