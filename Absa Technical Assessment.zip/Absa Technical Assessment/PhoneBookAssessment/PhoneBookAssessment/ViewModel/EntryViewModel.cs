﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PhoneBookAssessment.ViewModel
{
    public class EntryViewModel : PhoneBookViewModel
    {
     //   [Key]
        public int Entry_Id { get; set; }

        public string TypeEntry { get; set; }

        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Invalid mobile number")]
        public string Phone_Number { get; set; }

        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Entered phone format is not valid.")]
        public string Telephone_Number {get; set;}
}
}
