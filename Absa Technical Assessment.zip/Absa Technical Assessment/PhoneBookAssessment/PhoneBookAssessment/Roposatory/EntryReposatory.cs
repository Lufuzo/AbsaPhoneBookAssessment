﻿using Microsoft.EntityFrameworkCore;
using PhoneBookAssessment.Domain;
using PhoneBookAssessment.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PhoneBookAssessment.Roposatory
{
    public class EntryReposatory : IEntryReposatory
    {

        EntryDbContext _entryDbContext;
        public EntryReposatory(EntryDbContext entryDbContext)
        {
            _entryDbContext = entryDbContext;
        }
        public async Task<Entry> CreateEntry(Entry entry)
        {
            _entryDbContext.Entries.Add(entry);
            await _entryDbContext.SaveChangesAsync();
            return entry;
        }
        public async Task<IEnumerable<Entry>> GetEntries()
        {
            return await _entryDbContext.Entries.ToListAsync();
        }

        public async Task DeleteEntry(int id)
        {
            var entryToDelete = await _entryDbContext.Entries.FindAsync(id);
            _entryDbContext.Entries.Remove(entryToDelete);
            await _entryDbContext.SaveChangesAsync();
        }


        public async Task<Entry> GetEntryById(int id)
        {
            var record = await _entryDbContext.Entries.FindAsync(id);

            return record;
        }
    }
}
