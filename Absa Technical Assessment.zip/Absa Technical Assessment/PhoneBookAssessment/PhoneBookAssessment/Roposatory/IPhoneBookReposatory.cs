﻿using PhoneBookAssessment.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PhoneBookAssessment.Roposatory
{
   public interface IPhoneBookReposatory
    {
        Task<IEnumerable<PhoneBook>> GetPhoneBookEntries();
        Task<PhoneBook> GetPhoneBookEntryById(int id);
        Task<PhoneBook> CreatePhoneBookEntry(PhoneBook entry);
        Task DeletePhoneBookEntry(int id);




    }
}
