﻿using PhoneBookAssessment.Domain;
using PhoneBookAssessment.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace PhoneBookAssessment.Roposatory
{
    public class PhoneBookReposatory : IPhoneBookReposatory
    {

        PhoneBookDbContext _phoneBookEntryDbContext;
        public PhoneBookReposatory(PhoneBookDbContext phoneBookEntryDbContext)
        {
            _phoneBookEntryDbContext = phoneBookEntryDbContext;
        }

        public async Task<PhoneBook> CreatePhoneBookEntry(PhoneBook entry)
        {
            _phoneBookEntryDbContext.PhoneBookEntries.Add(entry);
            await _phoneBookEntryDbContext.SaveChangesAsync();
            return entry;
        }

        public async Task<IEnumerable<PhoneBook>> GetPhoneBookEntries()
        {
            return await _phoneBookEntryDbContext.PhoneBookEntries.ToListAsync();
        }

        public async Task<PhoneBook> GetPhoneBookEntryById(int id)
        {
            var record = await _phoneBookEntryDbContext.PhoneBookEntries.FindAsync(id);

            return record;
        }
        public async Task DeletePhoneBookEntry(int id)
        {
            var phoneBookEntryToDelete = await _phoneBookEntryDbContext.PhoneBookEntries.FindAsync(id);
            _phoneBookEntryDbContext.PhoneBookEntries.Remove(phoneBookEntryToDelete);
            await _phoneBookEntryDbContext.SaveChangesAsync();
        }
    }
}
