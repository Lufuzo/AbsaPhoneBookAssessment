﻿using PhoneBookAssessment.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PhoneBookAssessment.Roposatory
{
    public interface IEntryReposatory
    {
        Task<IEnumerable<Entry>> GetEntries();
        Task<Entry> GetEntryById(int id);
        Task<Entry> CreateEntry(Entry entry);
        Task DeleteEntry(int id);
    }
}
